package fr.uge.TheBigAventure;

public enum Intermittent {
	BUBBLE,
	DUST,
	;
}
