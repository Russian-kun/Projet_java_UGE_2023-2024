package fr.uge.TheBigAventure;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Objects;

public class World {

	private final int [][] ArrayWorld;
	private final int [] ArrayPow = {0, 0};
	private final int Height;
	private final int Width ;
	private final char [] Block;
	
	public World (int height , int width) {
		ArrayWorld = new int[height][width];
		Height = 0;
		Width = 0;
		Block = null;
		}
	
	static World readSize (String Line) {
		String[] Split;
		String[] Split2;
		int height;
		int width;
		
		Split = Line.split("\\(");
		Split2 = Split[1].split("\\)");
		height = Integer.parseInt(Split2[0].split("x")[0].split(" ")[0]);
		width = Integer.parseInt(Split2[0].split("x")[1].split(" ")[1]);
		System.out.println(height);
		System.out.println(width);
		return  new World(height,width);
		
	}
	
	static void readEncoding (String Line) {
		String[] Split;
		String[] Split2;
		char tmp1;
		char tmp2;
		System.out.println(Line);
		
	}
	
	
	public static  World readMap (String file) throws IOException {
		World map = null;
		try (var reader = Files.newBufferedReader(Paths.get("maps/" + file))) {
			String line1;
			String line2;
			String line3;
			
	    while ((line1 = reader.readLine()) != null) {
	    	line2 = line1;
	    	line3 = line1;
	    	for(var i = 0; i < line1.split("\n").length ; i++){
	    		map = readSize(line1.split("\n")[i]);
	    		System.out.println(line2);
	    	}
	    }
	    
		}
		System.out.println(map.Height);
		System.out.println(map.Width);

		return map;
	}

}
	