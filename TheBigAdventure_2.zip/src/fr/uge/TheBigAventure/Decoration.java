package fr.uge.TheBigAventure;

public enum Decoration {
	ALGAE,
	CLOUD,
	FLOWER,
	FOLIAGE,
	GRASS,
	LADDER,
	LILY,
	PLANK,
	REED,
	ROAD,
	SPROUT,
	TILE,
	TRACK,
	VINE,
	;
}
