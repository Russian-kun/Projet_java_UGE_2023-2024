package fr.uge.TheBigAventure;

import java.util.ArrayList;
import java.util.List;

public class EatingFood {
    private List<Food> foods;

    public EatingFood() {
        this.foods = new ArrayList<>();
        initializeFoods();
    }

    private void initializeFoods() {
        // Ajouter tous les éléments nutritifs avec leurs propriétés
        foods.add(new Food("BANANA", true, false));
        foods.add(new Food("BOBA", true, false));
        foods.add(new Food("BOTTLE", true, false));
        foods.add(new Food("BURGER", true, true));
        foods.add(new Food("CAKE", true, true));
        foods.add(new Food("CHEESE", true, true));
        foods.add(new Food("DONUT", true, true));
        foods.add(new Food("DRINK", true, false));
        foods.add(new Food("EGG", true, true));
        foods.add(new Food("FRUIT", true, false));
        foods.add(new Food("FUNGUS", true, true));
        foods.add(new Food("FUNGI", true, true));
        foods.add(new Food("LOVE", true, false));
        foods.add(new Food("PIZZA", true, true));
        foods.add(new Food("POTATO", true, true));
        foods.add(new Food("PUMPKIN", true, true));
        foods.add(new Food("TURNIP", true, true));
        foods.add(new Food("BUNNY", false, true));
        foods.add(new Food("CRAB", false, true));
        foods.add(new Food("FISH", false, true));
        foods.add(new Food("FROG", false, true));
        foods.add(new Food("SNAIL", false, true));
    }

    public boolean canBeEaten(String foodName, boolean isCooked) {
        for (Food food : foods) {
            if (food.getName().equalsIgnoreCase(foodName)) {
                if (isCooked) {
                    return food.canBeCooked();
                } else {
                    return food.canBeEatenRaw();
                }
            }
        }
        return false; // Food not found
    }

    public static void main(String[] args) {
        EatingFood eat = new EatingFood();

        // Exemple d'utilisation
        String foodName = "BURGER";
        boolean isCooked = true;

        if (eat.canBeEaten(foodName, isCooked)) {
            System.out.println(foodName + " peut être mangé.");
        } else {
            System.out.println(foodName + " ne peut pas être mangé.");
        }
    }
}