package fr.uge.TheBigAventure.main;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import fr.uge.TheBigAventure.Lexer;
import fr.uge.TheBigAventure.Result;
import fr.uge.TheBigAventure.World;

public class Main {
	
	public static void main(String[] args) throws IOException {
		var path = Path.of("../maps/demo.map");
    var text = Files.readString(path);
    var lexer = new Lexer(text);
    Result result;
    while((result = lexer.nextResult()) != null) {
      System.out.println(result);
    }
		//World carte = World.readMap("demo.map");
	}


}
