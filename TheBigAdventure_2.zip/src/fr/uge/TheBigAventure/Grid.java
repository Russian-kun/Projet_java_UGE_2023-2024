package fr.uge.TheBigAventure;

public class Grid {
	public Grid(int height, int widgh, String encoding , ) {
		
	}
}
