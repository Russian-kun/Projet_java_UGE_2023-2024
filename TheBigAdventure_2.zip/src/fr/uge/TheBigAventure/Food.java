package fr.uge.TheBigAventure;

public class Food {
  private final String name;
  private final boolean canBeEatenRaw;
  private final boolean canBeCooked;

  public Food(String name, boolean canBeEatenRaw, boolean canBeCooked) {
      this.name = name;
      this.canBeEatenRaw = canBeEatenRaw;
      this.canBeCooked = canBeCooked;
  }

  public String getName() {
      return name;
  }

  public boolean canBeEatenRaw() {
      return canBeEatenRaw;
  }

  public boolean canBeCooked() {
      return canBeCooked;
  }
}